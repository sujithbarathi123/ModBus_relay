/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define RS485_DE_PORT GPIOA
#define RS485_DE_PIN  GPIO_PIN_7

#define RS485_TX() HAL_GPIO_WritePin(RS485_DE_PORT, RS485_DE_PIN, GPIO_PIN_SET)
#define RS485_RX() HAL_GPIO_WritePin(RS485_DE_PORT, RS485_DE_PIN, GPIO_PIN_RESET)

#define AUTO_OFF_TIME_MS 180000UL  // 3 minutes

uint32_t coil0_start_time = 0;
uint32_t coil1_start_time = 0;

uint8_t coil0_active = 0;
uint8_t coil1_active = 0;



/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

uint16_t Modbus_CRC16(uint8_t *buf, uint16_t len)
{
    uint16_t crc = 0xFFFF;

    for (uint16_t pos = 0; pos < len; pos++)
    {
        crc ^= (uint16_t)buf[pos];

        for (int i = 0; i < 8; i++)
        {
            if (crc & 0x0001)
                crc = (crc >> 1) ^ 0xA001;
            else
                crc >>= 1;
        }
    }
    return crc;
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */


 /* USER CODE BEGIN 3 */

	  uint8_t rxBuf[32];
	  uint8_t txBuf[16];

	  uint32_t now = HAL_GetTick();

	  /* ================= AUTO-OFF TIMERS ================= */

	  if (coil0_active && (now - coil0_start_time >= AUTO_OFF_TIME_MS))
	  {
	      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
	      coil0_active = 0;
	      coil0_start_time = 0;
	  }

	  if (coil1_active && (now - coil1_start_time >= AUTO_OFF_TIME_MS))
	  {
	      HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
	      coil1_active = 0;
	      coil1_start_time = 0;
	  }

	  /* ================= MODBUS RECEIVE ================= */

	  RS485_RX();

	  /* ---- Read header (6 bytes) ---- */
	  if (HAL_UART_Receive(&huart1, rxBuf, 6, 500) != HAL_OK)
	      goto loop_end;

	  if (rxBuf[0] != 0x01)
	      goto loop_end;

	  uint8_t func = rxBuf[1];
	  uint16_t frame_len = 0;

	  /* ---- Read remaining bytes ---- */
	  if (func == 0x01 || func == 0x05)
	  {
	      if (HAL_UART_Receive(&huart1, &rxBuf[6], 2, 200) != HAL_OK)
	          goto loop_end;

	      frame_len = 8;
	  }
	  else if (func == 0x0F)
	  {
	      if (HAL_UART_Receive(&huart1, &rxBuf[6], 1, 200) != HAL_OK)
	          goto loop_end;

	      uint8_t byte_count = rxBuf[6];

	      if (HAL_UART_Receive(&huart1, &rxBuf[7], byte_count + 2, 300) != HAL_OK)
	          goto loop_end;

	      frame_len = 7 + byte_count + 2;
	  }
	  else
	  {
	      goto loop_end;
	  }

	  /* ---- CRC check ---- */
	  uint16_t crc_rx   = rxBuf[frame_len - 2] | (rxBuf[frame_len - 1] << 8);
	  uint16_t crc_calc = Modbus_CRC16(rxBuf, frame_len - 2);

	  if (crc_rx != crc_calc)
	      goto loop_end;

	  /* ================= FUNCTION HANDLING ================= */

	  /* ---------- FC01 : READ COILS ---------- */
	  if (func == 0x01)
	  {
	      uint16_t coil_addr = (rxBuf[2] << 8) | rxBuf[3];
	      uint8_t coil_value = 0x00;

	      if (coil_addr == 0)
	          coil_value = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) ? 0x01 : 0x00;
	      else if (coil_addr == 1)
	          coil_value = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1) ? 0x01 : 0x00;
	      else
	          goto loop_end;

	      txBuf[0] = 0x01;
	      txBuf[1] = 0x01;
	      txBuf[2] = 0x01;
	      txBuf[3] = coil_value;

	      uint16_t crc = Modbus_CRC16(txBuf, 4);
	      txBuf[4] = crc & 0xFF;
	      txBuf[5] = crc >> 8;

	      RS485_TX();
	      HAL_UART_Transmit(&huart1, txBuf, 6, 200);
	      RS485_RX();
	  }

	  /* ---------- FC05 : WRITE SINGLE COIL ---------- */
	  else if (func == 0x05)
	  {
	      uint16_t coil_addr = (rxBuf[2] << 8) | rxBuf[3];
	      uint8_t turn_on = (rxBuf[4] == 0xFF);

	      if (coil_addr == 0)
	      {
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, turn_on ? GPIO_PIN_SET : GPIO_PIN_RESET);
	          coil0_active = turn_on;
	          coil0_start_time = turn_on ? now : 0;
	      }
	      else if (coil_addr == 1)
	      {
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, turn_on ? GPIO_PIN_SET : GPIO_PIN_RESET);
	          coil1_active = turn_on;
	          coil1_start_time = turn_on ? now : 0;
	      }
	      else
	          goto loop_end;

	      RS485_TX();
	      HAL_UART_Transmit(&huart1, rxBuf, 8, 200);
	      RS485_RX();
	  }

	  /* ---------- FC0F : WRITE MULTIPLE COILS ---------- */
	  else if (func == 0x0F)
	  {
	      uint16_t start_addr = (rxBuf[2] << 8) | rxBuf[3];
	      uint16_t quantity   = (rxBuf[4] << 8) | rxBuf[5];
	      uint8_t data_byte   = rxBuf[7];

	      if (start_addr != 0 || quantity != 2)
	          goto loop_end;

	      // Coil 0
	      if (data_byte & 0x01)
	      {
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
	          coil0_active = 1;
	          coil0_start_time = now;
	      }
	      else
	      {
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
	          coil0_active = 0;
	          coil0_start_time = 0;
	      }

	      // Coil 1
	      if (data_byte & 0x02)
	      {
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
	          coil1_active = 1;
	          coil1_start_time = now;
	      }
	      else
	      {
	          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
	          coil1_active = 0;
	          coil1_start_time = 0;
	      }

	      txBuf[0] = 0x01;
	      txBuf[1] = 0x0F;
	      txBuf[2] = rxBuf[2];
	      txBuf[3] = rxBuf[3];
	      txBuf[4] = rxBuf[4];
	      txBuf[5] = rxBuf[5];

	      uint16_t crc = Modbus_CRC16(txBuf, 6);
	      txBuf[6] = crc & 0xFF;
	      txBuf[7] = crc >> 8;

	      RS485_TX();
	      HAL_UART_Transmit(&huart1, txBuf, 8, 200);
	      RS485_RX();
	  }

	  loop_end:
	  ;
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_7, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA0 PA1 PA2 PA7 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
